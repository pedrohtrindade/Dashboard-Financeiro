const API = {    //conf da api
  cotacoesAtuais: "https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL",
  historico: (codigo, dataInicial, dataFinal) => {
    const url = new URL(`https://economia.awesomeapi.com.br/json/daily/${codigo}-BRL/15`);

    if (dataInicial && dataFinal) {
      url.searchParams.set("start_date", formatarDataApi(dataInicial));
      url.searchParams.set("end_date", formatarDataApi(dataFinal));
    }

    return url.toString();
  }
};

const DIAS_POR_PERIODO = 15;

const estado = {
  cotacoes: {
    BTC: 0,
    USD: 0,
    EUR: 0,
    BRL: 1
  },
  grafico: null,
  moedaGrafico: "BTC",
  periodoGrafico: 0
};

const elementos = {
  statusText: document.getElementById("statusText"),
  messageBox: document.getElementById("messageBox"),
  refreshButton: document.getElementById("refreshButton"),
  converterForm: document.getElementById("converterForm"),
  amountInput: document.getElementById("amountInput"),
  fromCurrency: document.getElementById("fromCurrency"),
  toCurrency: document.getElementById("toCurrency"),
  swapButton: document.getElementById("swapButton"),
  conversionResult: document.getElementById("conversionResult"),
  chartButtons: document.querySelectorAll(".chart-button"),
  chartPeriod: document.getElementById("chartPeriod"),
  previousPeriodButton: document.getElementById("previousPeriodButton"),
  nextPeriodButton: document.getElementById("nextPeriodButton"),
  cards: {
    BTC: {
      value: document.getElementById("btcValue"),
      updated: document.getElementById("btcUpdated")
    },
    USD: {
      value: document.getElementById("usdValue"),
      updated: document.getElementById("usdUpdated")
    },
    EUR: {
      value: document.getElementById("eurValue"),
      updated: document.getElementById("eurUpdated")
    }
  }
};

const formatadores = {
  BRL: new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }),
  USD: new Intl.NumberFormat("pt-BR", { style: "currency", currency: "USD" }),
  EUR: new Intl.NumberFormat("pt-BR", { style: "currency", currency: "EUR" }),
  BTC: new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 8
  }),
  dataHora: new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short"
  }),
  dataCurta: new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit"
  })
};

function definirLoading(ativo, texto = "Carregando...") {
  document.body.classList.toggle("loading", ativo);
  elementos.statusText.textContent = texto;
}

function mostrarMensagem(texto, tipo = "erro") {
  elementos.messageBox.textContent = texto;
  elementos.messageBox.className = `message show ${tipo}`;

  window.setTimeout(() => {
    elementos.messageBox.className = "message";
  }, 6000);
}

function formatarValor(valor, moeda = "BRL") {
  if (moeda === "BTC") {
    return `${formatadores.BTC.format(valor)} BTC`;
  }

  return (formatadores[moeda] || formatadores.BRL).format(valor);
}

function formatarAtualizacao(timestampSegundos) {
  if (!timestampSegundos) {
    return formatadores.dataHora.format(new Date());
  }

  return formatadores.dataHora.format(new Date(Number(timestampSegundos) * 1000));
}

function formatarDataApi(data) {
  const ano = data.getFullYear();
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const dia = String(data.getDate()).padStart(2, "0");

  return `${ano}${mes}${dia}`;
}

function obterIntervaloHistorico(periodo) {
  if (periodo === 0) {
    return {
      dataInicial: null,
      dataFinal: null
    };
  }

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);

  const dataFinal = new Date(hoje);
  dataFinal.setDate(hoje.getDate() - (periodo * DIAS_POR_PERIODO));

  const dataInicial = new Date(dataFinal);
  dataInicial.setDate(dataFinal.getDate() - (DIAS_POR_PERIODO - 1));

  return {
    dataInicial,
    dataFinal
  };
}

// Busca as cotações atuais de BTC, USD e EUR em reais.
async function buscarCotacoes() {
  try {
    definirLoading(true, "Buscando cotações atualizadas...");

    const resposta = await fetch(API.cotacoesAtuais);

    if (!resposta.ok) {
      throw new Error("Não foi possível obter as cotações agora.");
    }

    const dados = await resposta.json();

    estado.cotacoes.BTC = Number(dados.BTCBRL.bid);
    estado.cotacoes.USD = Number(dados.USDBRL.bid);
    estado.cotacoes.EUR = Number(dados.EURBRL.bid);

    return {
      BTC: {
        valor: estado.cotacoes.BTC,
        atualizadoEm: formatarAtualizacao(dados.BTCBRL.timestamp)
      },
      USD: {
        valor: estado.cotacoes.USD,
        atualizadoEm: formatarAtualizacao(dados.USDBRL.timestamp)
      },
      EUR: {
        valor: estado.cotacoes.EUR,
        atualizadoEm: formatarAtualizacao(dados.EURBRL.timestamp)
      }
    };
  } catch (erro) {
    mostrarMensagem("As APIs de cotação não responderam. Tente novamente em instantes.");
    throw erro;
  } finally {
    definirLoading(false, `Última busca: ${formatadores.dataHora.format(new Date())}`);
  }
}

// Atualiza os cards principais com valores formatados.
async function atualizarCards() {
  try {
    const cotacoes = await buscarCotacoes();

    Object.entries(cotacoes).forEach(([moeda, dados]) => {
      elementos.cards[moeda].value.textContent = formatarValor(dados.valor, "BRL");
      elementos.cards[moeda].updated.textContent = `Última atualização: ${dados.atualizadoEm}`;
    });
  } catch (erro) {
    console.error("Erro ao atualizar cards:", erro);
  }
}

// Converte qualquer moeda suportada usando BRL como base intermediária.
async function converterMoeda(evento) {
  evento.preventDefault();

  const valor = Number(elementos.amountInput.value);
  const origem = elementos.fromCurrency.value;
  const destino = elementos.toCurrency.value;

  if (!Number.isFinite(valor) || valor < 0) {
    mostrarMensagem("Digite um valor válido para converter.");
    return;
  }

  try {
    await buscarCotacoes();

    const valorEmReais = valor * estado.cotacoes[origem];
    const valorConvertido = valorEmReais / estado.cotacoes[destino];

    elementos.conversionResult.innerHTML = `
      <span>${formatarValor(valor, origem)} equivale a</span>
      <strong>${formatarValor(valorConvertido, destino)}</strong>
    `;
  } catch (erro) {
    elementos.conversionResult.textContent = "Não foi possível concluir a conversão agora.";
  }
}

function normalizarHistorico(dados) {
  return dados
    .slice()
    .reverse()
    .map((item) => ({
      data: new Date(Number(item.timestamp) * 1000),
      valor: Number(item.bid)
    }));
}

async function buscarHistorico(moeda, periodo = 0) {
  const { dataInicial, dataFinal } = obterIntervaloHistorico(periodo);
  const url = API.historico(moeda, dataInicial, dataFinal);
  const resposta = await fetch(url);

  if (!resposta.ok) {
    throw new Error("Não foi possível carregar o histórico.");
  }

  const dados = await resposta.json();
  return normalizarHistorico(dados);
}

function corDaMoeda(moeda) {
  const cores = {
    BTC: "#f2a900",
    USD: "#14a06f",
    EUR: "#2f6fed"
  };

  return cores[moeda] || "#162033";
}

function nomeDaMoeda(moeda) {
  const nomes = {
    BTC: "Bitcoin",
    USD: "Dólar",
    EUR: "Euro",
    BRL: "Real"
  };

  return nomes[moeda] || moeda;
}

function atualizarPeriodoGrafico(historico, periodo) {
  if (!elementos.chartPeriod) {
    return;
  }

  if (!historico.length) {
    elementos.chartPeriod.textContent = "Nenhum dado encontrado para este período";
    return;
  }

  const primeiraData = historico[0].data;
  const ultimaData = historico[historico.length - 1].data;
  const intervalo = `${formatadores.dataCurta.format(primeiraData)} a ${formatadores.dataCurta.format(ultimaData)}`;
  const prefixo = periodo === 0 ? "Período mais recente" : `${periodo + 1}º bloco de 15 dias`;

  elementos.chartPeriod.textContent = `${prefixo}: ${intervalo}`;
}

function atualizarBotoesPeriodo() {
  elementos.nextPeriodButton.disabled = estado.periodoGrafico === 0;
}

// Carrega ou atualiza o gráfico de variação dos últimos 15 dias.
async function carregarGrafico(moeda = "BTC", periodo = estado.periodoGrafico) {
  try {
    definirLoading(true, `Carregando histórico de ${nomeDaMoeda(moeda)}...`);

    const historico = await buscarHistorico(moeda, periodo);
    const labels = historico.map((item) => formatadores.dataCurta.format(item.data));
    const valores = historico.map((item) => item.valor);
    const cor = corDaMoeda(moeda);
    const contexto = document.getElementById("variationChart");

    if (estado.grafico) {
      estado.grafico.destroy();
    }

    estado.grafico = new Chart(contexto, {
      type: "line",
      data: {
        labels,
        datasets: [{
          label: `${nomeDaMoeda(moeda)} em BRL`,
          data: valores,
          borderColor: cor,
          backgroundColor: `${cor}26`,
          borderWidth: 3,
          pointRadius: 4,
          pointHoverRadius: 6,
          pointBackgroundColor: "#ffffff",
          pointBorderColor: cor,
          pointBorderWidth: 2,
          fill: true,
          tension: 0.34
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          intersect: false,
          mode: "index"
        },
        plugins: {
          legend: {
            display: true,
            labels: {
              color: "#162033",
              font: {
                weight: "700"
              }
            }
          },
          tooltip: {
            callbacks: {
              label: (contextoTooltip) => formatarValor(contextoTooltip.parsed.y, "BRL")
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              color: "#657189"
            }
          },
          y: {
            grid: {
              color: "#e6ecf5"
            },
            ticks: {
              color: "#657189",
              callback: (valor) => formatarValor(valor, "BRL")
            }
          }
        }
      }
    });

    atualizarPeriodoGrafico(historico, periodo);
    atualizarBotoesPeriodo();
  } catch (erro) {
    console.error("Erro ao carregar gráfico:", erro);
    mostrarMensagem(`Não foi possível carregar o gráfico de ${nomeDaMoeda(moeda)}.`);
  } finally {
    definirLoading(false, `Última busca: ${formatadores.dataHora.format(new Date())}`);
  }
}

function configurarEventos() {
  elementos.refreshButton.addEventListener("click", atualizarCards);
  elementos.converterForm.addEventListener("submit", converterMoeda);

  elementos.swapButton.addEventListener("click", () => {
    const origem = elementos.fromCurrency.value;
    elementos.fromCurrency.value = elementos.toCurrency.value;
    elementos.toCurrency.value = origem;
  });

  elementos.chartButtons.forEach((botao) => {
    botao.addEventListener("click", () => {
      const moeda = botao.dataset.currency;

      elementos.chartButtons.forEach((item) => item.classList.remove("active"));
      botao.classList.add("active");
      estado.moedaGrafico = moeda;
      estado.periodoGrafico = 0;
      carregarGrafico(moeda);
    });
  });

  elementos.previousPeriodButton.addEventListener("click", () => {
    estado.periodoGrafico += 1;
    carregarGrafico(estado.moedaGrafico);
  });

  elementos.nextPeriodButton.addEventListener("click", () => {
    if (estado.periodoGrafico === 0) {
      return;
    }

    estado.periodoGrafico -= 1;
    carregarGrafico(estado.moedaGrafico);
  });
}

async function iniciarAplicacao() {
  configurarEventos();
  await atualizarCards();
  await carregarGrafico(estado.moedaGrafico);

  window.setInterval(atualizarCards, 60000);
}

document.addEventListener("DOMContentLoaded", iniciarAplicacao);
